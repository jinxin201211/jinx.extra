// var $base_request_url = "http://47.108.88.211:8082"; // todo
var $base_request_url = "http://211.82.246.251:8082";
// var $base_file_url = "http://47.108.88.211/img"; // todo
var $base_file_url = "http://211.82.246.251/img";
